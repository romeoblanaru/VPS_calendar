# MODIFICATION LOG

Added files only:
- index.html
- styles.css
- main.js
- assets/logo.svg
- CHANGELOG.md
