# CHANGELOG

## v2.0.0
- Complete landing page matching the requested copy and sections.
